package com.protts.app

import java.io.File
import java.io.RandomAccessFile

/**
 * Concatenates canonical PCM WAV data chunks.
 * The source WAVs must use the same format and a standard 44-byte PCM header.
 */
object WavMerger {
    fun merge(files: List<File>, destination: File) {
        require(files.isNotEmpty()) { "No audio segments" }
        val wavs = files.map { file ->
            val bytes = file.readBytes()
            require(bytes.size >= 44 && String(bytes, 0, 4) == "RIFF" && String(bytes, 8, 4) == "WAVE") {
                "TTS engine returned an unsupported WAV file"
            }
            require(String(bytes, 12, 4) == "fmt " && String(bytes, 36, 4) == "data") {
                "Only standard 44-byte PCM WAV files can be joined"
            }
            require(readInt(bytes, 16) == 16) { "Unsupported WAV format header" }
            bytes
        }
        val header = wavs.first().copyOfRange(0, 44)
        val format = header.copyOfRange(12, 36)
        require(wavs.all { it.copyOfRange(12, 36).contentEquals(format) }) {
            "Audio segments have different WAV formats"
        }
        val audioParts = wavs.map { bytes ->
            val dataLength = readInt(bytes, 40)
            require(dataLength >= 0 && 44 + dataLength <= bytes.size) { "Invalid WAV data length" }
            bytes.copyOfRange(44, 44 + dataLength)
        }
        val totalData = audioParts.sumOf { it.size }
        require(totalData <= Int.MAX_VALUE - 36) { "Audio file is too large" }
        writeInt(header, 4, 36 + totalData)
        writeInt(header, 40, totalData)
        RandomAccessFile(destination, "rw").use { output ->
            output.setLength(0)
            output.write(header)
            audioParts.forEach { output.write(it) }
        }
    }

    private fun readInt(bytes: ByteArray, offset: Int): Int =
        (bytes[offset].toInt() and 0xff) or
            ((bytes[offset + 1].toInt() and 0xff) shl 8) or
            ((bytes[offset + 2].toInt() and 0xff) shl 16) or
            ((bytes[offset + 3].toInt() and 0xff) shl 24)

    private fun writeInt(bytes: ByteArray, offset: Int, value: Int) {
        for (i in 0..3) bytes[offset + i] = (value ushr (8 * i)).toByte()
    }
}

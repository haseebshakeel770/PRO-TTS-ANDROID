package com.protts.app

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale

private val Navy = Color(0xFF0B1024)
private val Purple = Color(0xFF7657F6)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var engineReady by mutableStateOf(false)
    private var status by mutableStateOf("Speech engine شروع ہو رہا ہے…")
    private var locales by mutableStateOf(listOf<String>())
    private var selectedLocale by mutableStateOf("en-US")
    private var outputFile by mutableStateOf<File?>(null)
    private var player: MediaPlayer? = null
    private var isPlaying by mutableStateOf(false)
    private var speechRate by mutableFloatStateOf(1f)
    private var speechPitch by mutableFloatStateOf(1f)
    private var saveSource: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            ProTtsApp(
                ready = engineReady,
                status = status,
                locales = locales,
                selectedLocale = selectedLocale,
                onLocaleChange = { selectedLocale = it },
                rate = speechRate,
                onRateChange = { speechRate = it },
                pitch = speechPitch,
                onPitchChange = { speechPitch = it },
                outputName = outputFile?.name,
                playing = isPlaying,
                onConvert = { convertText(it) },
                onPlay = { playAudio() },
                onPause = { pauseAudio() },
                onStop = { stopAudio() },
                onSave = { saveAudio() },
                onShare = { shareAudio() },
                onOpenTtsSettings = { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
            )
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            engineReady = true
            locales = tts?.availableLanguages.orEmpty()
                .filter { it.language.isNotBlank() }
                .map { it.toLanguageTag() }
                .distinct()
                .sorted()
            if (locales.isNotEmpty() && selectedLocale !in locales) selectedLocale = locales.first()
            status = "Ready — ${locales.size} زبانیں/لوکیلز دستیاب"
        } else {
            status = "TTS Engine شروع نہیں ہوسکا۔ فون کی Settings میں Speech Engine فعال کریں۔"
        }
    }

    private fun convertText(text: String) {
        val engine = tts ?: return
        if (!engineReady || text.isBlank()) {
            status = "براہ کرم ٹیکسٹ لکھیں اور انجن تیار ہونے کا انتظار کریں۔"
            return
        }
        val locale = Locale.forLanguageTag(selectedLocale)
        if (engine.isLanguageAvailable(locale) < TextToSpeech.LANG_AVAILABLE) {
            status = "منتخب زبان اس فون کے TTS انجن میں دستیاب نہیں۔"
            return
        }
        engine.language = locale
        engine.setSpeechRate(speechRate)
        engine.setPitch(speechPitch)

        val chunks = splitText(text, TextToSpeech.getMaxSpeechInputLength() - 100)
        val tempDir = File(cacheDir, "tts_parts").apply { mkdirs() }
        val parts = chunks.indices.map { File(tempDir, "part_$it.wav") }
        var current = 0
        status = "آڈیو تیار ہو رہی ہے: 0/${chunks.size}"

        fun synthesizeNext() {
            if (current >= chunks.size) {
                try {
                    val merged = File(cacheDir, "PRO_TTS_${System.currentTimeMillis()}.wav")
                    if (parts.size == 1) parts[0].copyTo(merged, overwrite = true)
                    else WavMerger.merge(parts, merged)
                    outputFile = merged
                    status = "آڈیو کامیابی سے تیار ہوگئی۔ WAV فارمیٹ"
                } catch (e: Exception) {
                    status = "آڈیو جوڑنے میں مسئلہ: ${e.message ?: "Unknown error"}"
                }
                return
            }
            val partIndex = current
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) {
                    runOnUiThread {
                        current++
                        status = "آڈیو تیار ہو رہی ہے: $current/${chunks.size}"
                        synthesizeNext()
                    }
                }
                override fun onError(utteranceId: String?) {
                    runOnUiThread { status = "حصہ ${partIndex + 1} کی آڈیو نہیں بن سکی۔ Voice Data چیک کریں۔" }
                }
            })
            val result = engine.synthesizeToFile(chunks[partIndex], Bundle(), parts[partIndex], "part_$partIndex")
            if (result != TextToSpeech.SUCCESS) status = "TTS نے آڈیو بنانے کی درخواست قبول نہیں کی۔"
        }
        synthesizeNext()
    }

    private fun splitText(input: String, maxLength: Int): List<String> {
        val remaining = input.trim()
        if (remaining.length <= maxLength) return listOf(remaining)
        val result = mutableListOf<String>()
        var rest = remaining
        while (rest.isNotEmpty()) {
            if (rest.length <= maxLength) {
                result.add(rest)
                break
            }
            var cut = rest.lastIndexOfAny(charArrayOf('.', '!', '?', '۔', '\n', '،', ';', ':'), maxLength)
            if (cut < maxLength / 2) cut = rest.lastIndexOf(' ', maxLength)
            if (cut <= 0) cut = maxLength
            result.add(rest.substring(0, cut + 1).trim())
            rest = rest.substring((cut + 1).coerceAtMost(rest.length)).trim()
        }
        return result.filter { it.isNotBlank() }
    }

    private fun playAudio() {
        val file = outputFile ?: return
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnPreparedListener { mp -> mp.start(); isPlaying = true }
                setOnCompletionListener { isPlaying = false }
                prepareAsync()
            }
        } catch (e: Exception) {
            status = "Playback error: ${e.message}"
        }
    }

    private fun pauseAudio() {
        if (player?.isPlaying == true) {
            player?.pause()
            isPlaying = false
        }
    }

    private fun stopAudio() {
        player?.let {
            try { it.stop() } catch (_: IllegalStateException) { }
            it.release()
        }
        player = null
        isPlaying = false
    }

    private fun saveAudio() {
        val file = outputFile ?: return
        saveSource = file
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/wav"
            putExtra(Intent.EXTRA_TITLE, file.name)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, 701)
    }

    @Deprecated("Uses the Storage Access Framework result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 701 && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            try {
                uri?.let { destination ->
                    contentResolver.openOutputStream(destination)?.use { out ->
                        saveSource?.inputStream()?.use { input -> input.copyTo(out) }
                    }
                }
                status = "آڈیو فائل محفوظ ہوگئی۔"
            } catch (e: Exception) {
                status = "فائل محفوظ نہیں ہوسکی: ${e.message}"
            }
        }
    }

    private fun shareAudio() {
        val file = outputFile ?: return
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/wav"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(shareIntent, "Share PRO TTS audio"))
    }

    override fun onDestroy() {
        player?.release()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProTtsApp(
    ready: Boolean,
    status: String,
    locales: List<String>,
    selectedLocale: String,
    onLocaleChange: (String) -> Unit,
    rate: Float,
    onRateChange: (Float) -> Unit,
    pitch: Float,
    onPitchChange: (Float) -> Unit,
    outputName: String?,
    playing: Boolean,
    onConvert: (String) -> Unit,
    onPlay: () -> Unit,
    onPause: () -> Unit,
    onStop: () -> Unit,
    onSave: () -> Unit,
    onShare: () -> Unit,
    onOpenTtsSettings: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    var menuExpanded by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Navy, surface = Color(0xFF1B2240))) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Navy, Color(0xFF211849))))
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("PRO TTS", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Your Personal Voice Studio", color = Color(0xFFC6C2E8))
                }
                Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Color(0xFF9D8BFF), modifier = Modifier.size(44.dp))
            }
            Spacer(Modifier.height(20.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2240))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("TEXT TO SPEECH", color = Color(0xFFC0B6FF), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier.fillMaxWidth().height(210.dp),
                        placeholder = { Text("یہاں اپنا ٹیکسٹ لکھیں یا پیسٹ کریں…", color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Purple,
                            unfocusedBorderColor = Color(0xFF596080),
                            cursorColor = Color.White
                        )
                    )
                    Text("${text.length} characters", color = Color.LightGray, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("LANGUAGE", color = Color(0xFFC0B6FF), fontWeight = FontWeight.Bold)
                    ExposedDropdownMenuBox(expanded = menuExpanded, onExpandedChange = { menuExpanded = it }) {
                        OutlinedTextField(
                            value = selectedLocale,
                            onValueChange = {},
                            readOnly = true,
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = menuExpanded) },
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                        ExposedDropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                            locales.forEach { language ->
                                DropdownMenuItem(
                                    text = { Text(language) },
                                    onClick = { onLocaleChange(language); menuExpanded = false }
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("SPEECH SPEED  ${"%.1f".format(rate)}×", color = Color.White)
                    Slider(value = rate, onValueChange = onRateChange, valueRange = 0.5f..2.0f)
                    Text("PITCH  ${"%.1f".format(pitch)}×", color = Color.White)
                    Slider(value = pitch, onValueChange = onPitchChange, valueRange = 0.5f..2.0f)
                    Button(
                        onClick = { onConvert(text) },
                        enabled = ready && text.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)
                    ) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("CONVERT TO SPEECH")
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2240))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("AUDIO PLAYER", color = Color(0xFFC0B6FF), fontWeight = FontWeight.Bold)
                    Text(outputName ?: "ابھی کوئی آڈیو تیار نہیں ہوئی", color = Color.White)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        IconButton(onClick = onPlay, enabled = outputName != null) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White)
                        }
                        IconButton(onClick = onPause, enabled = playing) {
                            Icon(Icons.Default.Pause, contentDescription = "Pause", tint = Color.White)
                        }
                        IconButton(onClick = onStop, enabled = outputName != null) {
                            Icon(Icons.Default.Stop, contentDescription = "Stop", tint = Color.White)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onSave, enabled = outputName != null) {
                            Icon(Icons.Default.Save, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("Save WAV")
                        }
                        OutlinedButton(onClick = onShare, enabled = outputName != null) {
                            Icon(Icons.Default.Share, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("Share")
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(status, color = Color(0xFFD2CFF0), fontSize = 13.sp)
            TextButton(onClick = onOpenTtsSettings) { Text("فون کی TTS Voice Settings کھولیں") }
            Text("نوٹ: دستیاب زبانیں اور آوازیں فون کے Speech Engine پر منحصر ہیں۔", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

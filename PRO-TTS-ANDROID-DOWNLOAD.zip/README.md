# PRO TTS — GitHub سے APK بنانے کا طریقہ

یہ Android ایپ فون میں پہلے سے موجود Android Text-to-Speech انجن استعمال کرتی ہے۔ کسی Paid API Key یا سرور کی ضرورت نہیں۔ دستیاب زبانیں اور آوازیں فون کے TTS انجن پر منحصر ہیں۔ آڈیو WAV فارمیٹ میں بنتی ہے؛ MP3 اس ورژن میں شامل نہیں۔

## GitHub پر اپلوڈ کرنے کے مراحل

1. `PRO-TTS-ANDROID.zip` کو اپنی GitHub Repository کے root میں اپلوڈ کریں۔
2. اسی Repository میں `.github/workflows/build.yml` فائل بنائیں اور فراہم کردہ `build.yml` کا مکمل کوڈ اس میں پیسٹ کریں۔
3. GitHub کے **Actions** ٹیب میں جائیں۔
4. `Build APK` ورک فلو مکمل ہونے کا انتظار کریں۔
5. کامیاب Build کے بعد **Artifacts** میں `App-apk` ڈاؤن لوڈ کریں۔

## Android Studio سے Build

Android Studio میں ZIP کو Extract کرکے اس پروجیکٹ فولڈر کو کھولیں۔ JDK 17 اور Android SDK 34 درکار ہیں۔ Gradle 8.7 استعمال کریں۔

## اہم نوٹ

- Urdu، Hindi اور دیگر زبانوں کی دستیابی فون کے TTS engine اور انسٹال Voice Data پر منحصر ہے۔
- اگر آواز دستیاب نہ ہو تو Android Settings → Text-to-speech output میں Voice Data انسٹال کریں۔
- اس ZIP میں مکمل Buildable starter app اور WAV synthesis شامل ہے۔ اسے مختلف فونز پر ٹیسٹ کرکے ہی ریلیز کریں۔

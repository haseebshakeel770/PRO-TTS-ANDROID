# PRO TTS — Android

A zero-paid-API Android Text-to-Speech starter app using the speech engine installed on the device.

## Current implementation
- Native Android `TextToSpeech` engine (no API key/server).
- Dynamically lists locales reported by the installed engine.
- Runtime language validation, speech rate and pitch controls.
- Actual audio synthesis to WAV using `synthesizeToFile`.
- Long input is split at sentence/punctuation boundaries and WAV chunks are joined when the device engine emits compatible PCM WAV output.
- Playback, save via Android Storage Access Framework, and share.
- GitHub Actions debug APK build.

## Important limitations (read before publishing)
1. Speech quality, available languages, gender/voice choices, and offline behavior depend on the TTS engine and voice data installed on each phone. The app does not invent Urdu/Hindi voices. Check Android Settings → Text-to-speech output and install the desired voice data if offered.
2. `availableLanguages` is queried from the engine. Not every engine reports voice metadata consistently; this starter does not label voices as male/female unless the engine explicitly provides that data.
3. Export is WAV, not MP3. No false MP3 extension is used. MP3 encoding is not included in this first zero-cost baseline.
4. WAV joining validates the format header; unusual engine output formats may not join and will show an error.
5. This is a functional baseline, not a fully verified production release. Test on your target Android devices before publishing.

## Build
- Android Studio with JDK 17 and Android SDK 35.
- Open this folder as a project, allow Gradle sync, then Build → Build Bundle(s) / APK(s) → Build APK(s).
- Or with Gradle 8.9 installed: `gradle assembleDebug`
- APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
Push to `main` or `master`, or run the workflow manually. Download the `PRO-TTS-debug-apk` artifact from the Actions run.

## Language / offline setup
Open the phone's Settings → System (or General Management) → Text-to-speech output. Select an installed engine and download voice data if available. Some voices require network access; offline availability is engine-specific.

## License
Project code: MIT. Third-party Android/Jetpack components retain their respective licenses.

package com.protts.app

import java.io.File
import java.io.RandomAccessFile

/**
 * Joins standard PCM WAV files with identical format by concatenating their data chunks.
 * If a device TTS engine emits a non-PCM or unusual WAV, joining fails safely.
 */
object WavJoiner {
    fun join(parts: List<File>, output: File) {
        require(parts.isNotEmpty())
        val parsed = parts.map { file ->
            val bytes = file.readBytes()
            require(bytes.size >= 44 && String(bytes, 0, 4) == "RIFF" && String(bytes, 8, 4) == "WAVE") { "Unsupported WAV container" }
            val fmt = bytes.copyOfRange(12, 36)
            val dataOffset = findData(bytes)
            Triple(bytes, fmt, dataOffset)
        }
        val format = parsed.first().second
        require(parsed.all { it.second.contentEquals(format) }) { "Audio segments have different WAV formats" }
        val data = parsed.map { (b, _, offset) -> b.copyOfRange(offset + 8, offset + 8 + littleInt(b, offset + 4)) }
        val total = data.sumOf { it.size }
        RandomAccessFile(output, "rw").use { raf ->
            raf.setLength(0)
            raf.write("RIFF".toByteArray()); writeInt(raf, 36 + total)
            raf.write("WAVE".toByteArray())
            raf.write(format)
            raf.write("data".toByteArray()); writeInt(raf, total)
            data.forEach { raf.write(it) }
        }
    }
    private fun findData(b: ByteArray): Int {
        var p = 12
        while (p + 8 <= b.size) {
            val id = String(b, p, 4)
            val size = littleInt(b, p + 4)
            if (id == "data") return p
            p += 8 + size + (size and 1)
        }
        error("WAV data chunk missing")
    }
    private fun littleInt(b: ByteArray, p: Int) = (b[p].toInt() and 255) or ((b[p+1].toInt() and 255) shl 8) or ((b[p+2].toInt() and 255) shl 16) or ((b[p+3].toInt() and 255) shl 24)
    private fun writeInt(raf: RandomAccessFile, value: Int) {
        raf.write(value and 255); raf.write((value shr 8) and 255); raf.write((value shr 16) and 255); raf.write((value shr 24) and 255)
    }
}

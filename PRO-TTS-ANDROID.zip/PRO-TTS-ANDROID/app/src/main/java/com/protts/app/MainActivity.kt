package com.protts.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.media.MediaPlayer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale

private val Navy = Color(0xFF0B1024)
private val Purple = Color(0xFF7657F6)
private val Blue = Color(0xFF278BFA)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready by mutableStateOf(false)
    private var status by mutableStateOf("Initializing speech engine…")
    private var audioFile by mutableStateOf<File?>(null)
    private var player: MediaPlayer? = null
    private var playing by mutableStateOf(false)
    private var duration by mutableIntStateOf(0)
    private var progress by mutableIntStateOf(0)
    private var selectedLocale by mutableStateOf("en-US")
    private var availableLocales by mutableStateOf(listOf<String>())
    private var rate by mutableFloatStateOf(1f)
    private var pitch by mutableFloatStateOf(1f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            ProTtsScreen(
                ready = ready, status = status, locales = availableLocales,
                selectedLocale = selectedLocale, onLocale = { selectedLocale = it },
                rate = rate, onRate = { rate = it }, pitch = pitch, onPitch = { pitch = it },
                audioFile = audioFile, playing = playing, duration = duration, progress = progress,
                onConvert = { text -> convert(text) },
                onPlay = { play() }, onPause = { pause() }, onStop = { stop() },
                onSave = { saveWithPicker() }, onShare = { share() },
                onSettings = { openTtsSettings() }
            )
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            ready = true
            val locales = tts?.availableLanguages.orEmpty()
                .filter { it.language.isNotBlank() }
                .map { it.toLanguageTag() }.distinct().sorted()
            availableLocales = locales
            if (locales.isNotEmpty() && selectedLocale !in locales) selectedLocale = locales.first()
            status = "Ready • ${locales.size} language/locale options detected"
        } else status = "TTS engine initialization failed. Install/enable a speech engine."
    }

    private fun convert(input: String) {
        val engine = tts ?: return
        if (!ready || input.isBlank()) { status = "Enter text and wait for the engine."; return }
        val locale = Locale.forLanguageTag(selectedLocale)
        val availability = engine.isLanguageAvailable(locale)
        if (availability < 0) { status = "Selected language is not supported by this device's TTS engine."; return }
        engine.language = locale
        engine.setSpeechRate(rate)
        engine.setPitch(pitch)
        val chunks = splitText(input, TextToSpeech.getMaxSpeechInputLength() - 100)
        val dir = File(cacheDir, "tts_chunks").apply { mkdirs() }
        val outputs = chunks.mapIndexed { i, _ -> File(dir, "part_$i.wav") }
        var index = 0
        status = "Preparing ${chunks.size} audio segment(s)…"
        fun synthesizeNext() {
            if (index >= chunks.size) {
                try {
                    val target = File(getExternalFilesDir("Audio") ?: filesDir, "PRO_TTS_${System.currentTimeMillis()}.wav")
                    if (outputs.size == 1) outputs[0].copyTo(target, overwrite = true)
                    else WavJoiner.join(outputs, target)
                    audioFile = target
                    status = "Audio created successfully • WAV"
                } catch (e: Exception) { status = "Audio assembly failed: ${e.message}" }
                return
            }
            val current = index
            val params = Bundle()
            val id = "part_$current"
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    runOnUiThread {
                        index++
                        status = "Converting segment $index of ${chunks.size}…"
                        synthesizeNext()
                    }
                }
                override fun onError(utteranceId: String?) {
                    runOnUiThread { status = "TTS failed on segment ${current + 1}. Check voice data and language." }
                }
            })
            val result = engine.synthesizeToFile(chunks[current], params, outputs[current], id)
            if (result != TextToSpeech.SUCCESS) status = "Could not synthesize segment ${current + 1}."
        }
        synthesizeNext()
    }

    private fun splitText(text: String, max: Int): List<String> {
        val result = mutableListOf<String>()
        var rest = text.trim()
        while (rest.isNotEmpty()) {
            if (rest.length <= max) { result += rest; break }
            var cut = rest.lastIndexOfAny(charArrayOf('.', '!', '?', '۔', '\n', '،', ';', ':'), max)
            if (cut < max / 2) cut = rest.lastIndexOf(' ', max)
            if (cut <= 0) cut = max
            result += rest.substring(0, cut + 1).trim()
            rest = rest.substring((cut + 1).coerceAtMost(rest.length)).trim()
        }
        return result
    }

    private fun play() {
        val file = audioFile ?: return
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnPreparedListener { it.start(); playing = true; duration = it.duration }
                setOnCompletionListener { playing = false; progress = duration }
                prepareAsync()
            }
        } catch (e: Exception) { status = "Playback error: ${e.message}" }
    }
    private fun pause() { player?.pause(); playing = false }
    private fun stop() { player?.stop(); player?.release(); player = null; playing = false; progress = 0 }
    private fun saveWithPicker() {
        val file = audioFile ?: run { status = "Create audio first."; return }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "audio/wav"
            putExtra(Intent.EXTRA_TITLE, file.name)
        }
        saveSource = file
        @Suppress("DEPRECATION")
        startActivityForResult(intent, 501)
    }
    private var saveSource: File? = null
    @Deprecated("Legacy activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 501 && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            try { uri?.let { contentResolver.openOutputStream(it)?.use { out -> saveSource?.inputStream()?.use { input -> input.copyTo(out) } } }; status = "Saved audio file." }
            catch (e: Exception) { status = "Save failed: ${e.message}" }
        }
    }
    private fun share() {
        val file = audioFile ?: return
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply { type = "audio/wav"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(Intent.createChooser(intent, "Share PRO TTS audio"))
    }
    private fun openTtsSettings() { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }

    override fun onDestroy() {
        player?.release()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProTtsScreen(
    ready: Boolean, status: String, locales: List<String>, selectedLocale: String, onLocale: (String) -> Unit,
    rate: Float, onRate: (Float) -> Unit, pitch: Float, onPitch: (Float) -> Unit,
    audioFile: File?, playing: Boolean, duration: Int, progress: Int,
    onConvert: (String) -> Unit, onPlay: () -> Unit, onPause: () -> Unit, onStop: () -> Unit,
    onSave: () -> Unit, onShare: () -> Unit, onSettings: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Navy, surface = Color(0xFF171D36))) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, Color(0xFF17143A)))).verticalScroll(rememberScrollState()).padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("PRO TTS", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Your personal voice studio", color = Color(0xFFB9B8D5))
                }
                Icon(Icons.Default.GraphicEq, null, tint = Color(0xFF9D8BFF), modifier = Modifier.size(42.dp))
            }
            Spacer(Modifier.height(20.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1C2442)), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("TEXT INPUT", color = Color(0xFFBDB5FF), fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth().height(220.dp),
                        placeholder = { Text("Type or paste your text here…", color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF515879)))
                    Text("${text.length} characters", color = Color.LightGray)
                    Spacer(Modifier.height(12.dp))
                    Text("LANGUAGE / INSTALLED VOICES", color = Color(0xFFBDB5FF), fontWeight = FontWeight.Bold)
                    if (locales.isEmpty()) Text("No language list available yet.", color = Color.LightGray)
                    else {
                        var expanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                            OutlinedTextField(value = selectedLocale, onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(), trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                locales.forEach { lang -> DropdownMenuItem(text = { Text(lang) }, onClick = { onLocale(lang); expanded = false }) }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("SPEECH SPEED  ${"%.2f".format(rate)}×", color = Color.White)
                    Slider(value = rate, onValueChange = onRate, valueRange = 0.5f..2f)
                    Text("PITCH  ${"%.2f".format(pitch)}×", color = Color.White)
                    Slider(value = pitch, onValueChange = onPitch, valueRange = 0.5f..2f)
                    Button(onClick = { onConvert(text) }, enabled = ready && text.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                        Icon(Icons.Default.RecordVoiceOver, null); Spacer(Modifier.width(8.dp)); Text("CONVERT TO SPEECH")
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1C2442)), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("AUDIO PLAYER", color = Color(0xFFBDB5FF), fontWeight = FontWeight.Bold)
                    Text(audioFile?.name ?: "No audio generated yet", color = Color.White)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        IconButton(onClick = onPlay, enabled = audioFile != null) { Icon(Icons.Default.PlayArrow, "Play", tint = Color.White) }
                        IconButton(onClick = onPause, enabled = playing) { Icon(Icons.Default.Pause, "Pause", tint = Color.White) }
                        IconButton(onClick = onStop, enabled = audioFile != null) { Icon(Icons.Default.Stop, "Stop", tint = Color.White) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onSave, enabled = audioFile != null) { Text("Save WAV") }
                        OutlinedButton(onClick = onShare, enabled = audioFile != null) { Text("Share") }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(status, color = Color(0xFFCBC8E8))
            TextButton(onClick = onSettings) { Text("TTS engine & voice settings") }
            Text("PRO TTS • Free on-device Android speech engine", color = Color.Gray, fontSize = 11.sp)
        }
    }
}
